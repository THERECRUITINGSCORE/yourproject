from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('select_mode.html')

@app.route('/player_form')
def player_form():
    return render_template('player_form.html')

@app.route('/results', methods=['POST'])
def results():
    try:
        name = request.form['name']
        school = request.form['school']
        gpa = float(request.form['gpa'])
        sat = int(request.form['sat'])
        team = request.form['team']
        position = request.form['position']
        height = float(request.form['height'])  # in inches

        score = 0

        # GPA
        if gpa >= 3.8:
            score += 1

        # SAT
        if sat >= 1400:
            score += 1

        # Team level
        team_lower = team.lower()
        if "mls" in team_lower:
            score += 5
        elif "ecnl" in team_lower:
            score += 3
        else:
            score += 1

        # Height scoring
        if height >= 74:  # 6'2"+
            score += 3
        elif height >= 72:  # 6'0"+
            score += 2
        else:
            score += 1

        # Max score capped at 10
        score = min(score, 10)

        return render_template('results.html', name=name, score=score)

    except Exception as e:
        return f"Error: {str(e)}"

if __name__ == '__main__':
    app.run(debug=True)